package com.qvsu.quartz.config;

/**
 * Quartz 调度配置占位类。
 *
 * 当前使用 Spring Boot 自动配置的 Scheduler（内存模式）。
 * 如需切换为 JDBC JobStore，可在此处补充 SchedulerFactoryBean 配置。
 *
 * @author qvsu
 */
public class ScheduleConfig
{
}

