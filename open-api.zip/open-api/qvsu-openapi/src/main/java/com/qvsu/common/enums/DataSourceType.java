package com.qvsu.common.enums;

/**
 * 数据源
 * 
 * @author qvsu
 */
public enum DataSourceType
{
    /**
     * 主库
     */
    MASTER,

    /**
     * 从库
     */
    SLAVE
}
