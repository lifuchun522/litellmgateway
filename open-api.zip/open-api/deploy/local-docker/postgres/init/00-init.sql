-- PostgreSQL init entrypoint for jd_openapi
SET client_encoding = 'UTF8';
SET timezone = 'Asia/Shanghai';



